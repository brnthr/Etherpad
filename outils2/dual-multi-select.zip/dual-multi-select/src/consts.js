export const NAMESPACE = 'simple-multi-select';
